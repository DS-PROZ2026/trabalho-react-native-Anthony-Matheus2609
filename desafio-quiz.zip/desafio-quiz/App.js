import React, { useState } from 'react';
// 1. IMPORTAMOS O COMPONENTE IMAGE AQUI:
import { View, Text, TouchableOpacity, ActivityIndicator, StyleSheet, Image } from 'react-native';
const QUIZ = [
{
id: 1,
pergunta: 'Twin peaks é uma cidade que faz fronteira com que país?',
imagem : 'https://rollingstone.com.br/wp-content/uploads/2025/06/qual-a-ordem-cronologica-dos-filmes-e-series-de-twin-peaks.jpg',
opcoes: [
'a) Canadá ', 

'b) México ', 

'c) Alemanha', 

'd) Suiça'],
respostaCerta: 0
},
{
id: 2,
pergunta: 'Que personagem é responsável por gerir um negócio de tráfico de drogas em Breaking Bad?',
imagem: 'https://static.wikia.nocookie.net/assista-series/images/5/56/Breaking-Bad.jpg/revision/latest/scale-to-width-down/1200?cb=20150528205254&path-prefix=pt-br',
opcoes: [
'A) Jesse Pinkman' ,
'B) Saul Goodman' ,
'C )Gustavo Fring' ,
'D )Walter White'],
respostaCerta: 2
},
{
id: 3,
pergunta: 'A afirmação "O fim do mundo em Dark ocorre em  2020" está correta?',
imagem: 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjIe8U6hmTJLI9TCOFpHYyWBX-ObYhCC6A-ny4updr06mkutq5zPjyyJZgO5AGSNPTWTnMuAy5q5tW0DM9liOIE7qNIrQs4KmSUPmV5WhDp1M3s87SE2D4VFwWhtnMwbAMaUsHfW6m0weJW/s1600/03+-+Dark+2x02+%25E2%2580%2593+Dunkle+Materie+%2528Mat%25C3%25A9ria+Escura%2529.jpg',
opcoes: ['Está correta', 'Não está correta'],
respostaCerta: 0
},
{
id: 4,
pergunta: 'Qual desses livros é importante para a trama de True Detective?',
imagem: 'https://rollingstone.com.br/wp-content/uploads/legacy/2014/img-1020450-galeria-series-de-tv-de-2014-true-detective.jpg',
opcoes: [
'A) A Bíblia Sagrada' ,
'B) A Cor que caiu do Espaço' ,
'C) O Retrato de Dorian Gray' ,
'D) O Rei de Amarelo'],
respostaCerta: 3
},
{
id: 5,
pergunta: 'Na série "From", qual é o meio em que os cidadãos chegam até "A Cidade"?',
imagem: 'https://m.media-amazon.com/images/S/pv-target-images/2b6156f47751daf692f29b27326ee52e5ddabee6953e60d6b2bae32d37e9bd64.jpg',
opcoes: [
'A) Encontrando numa floresta perto dos montes Apalanche' ,
'B) Viagem Dimensional' ,
'C) São transportados após a morte' ,
'D) Numa queda de Avião'],
respostaCerta: 1
},
{
id: 6,
pergunta: 'Em Twin Peaks, o personagem do Dale Cooper recebe revelações da sua investigação em:',
imagem: 'https://media.revistagq.com/photos/5ca5faffb7380805e28196f1/master/w_1600,c_limit/twin_peaks_3328.jpg',
opcoes: [
'A) Uma conversa com um suspeito' ,
'B) Encontrando uma pista no local do crime' ,
'C) Em seus sonhos' ,
'D) Pegando o criminoso no flagra'],
respostaCerta: 2
},
{
  
id: 7,
pergunta: 'Qual desses episódios de breaking bad o personagem Jesse Pinkman invade uma casa onde enfrenta problemas com um casal de usuários de drogas?',
imagem: 'https://i.pinimg.com/originals/87/4c/0e/874c0ec468c01e0e87c590e2709aaf9a.jpg',
opcoes: [
'A) Peekaboo (Temporada 2, episódio 5)' ,
'B) Gray Matter (Temporada 1, episódio 5)' ,
'C) Half Measures (Temporada 3, episódio 12' ,
'D) Rabid Dog(Temporada 5, episódio, 12 )'],
respostaCerta: 0
},
{
id: 8,
pergunta: 'Dark gira em torno de ciclos de quantos anos?',
imagem: 'https://i.pinimg.com/1200x/4a/71/da/4a71daa369a5f423c82007a7428c37c3.jpg',
opcoes: [
'A) 25 anos' ,
'B)33 anos' ,
'C)50 anos' , 
'D)42 anos'],
respostaCerta: 1
},
{
id: 9,
pergunta: 'Em True detective, antes de assumir o caso de Dora Lange, Rustin cohle trabalhava como agente infiltrado no narcotráfico.Essa afirmação é:',
imagem: 'https://cdn.prod.www.spiegel.de/images/b508b49f-0001-0004-0000-000000586563_w1200_r1.33_fpx33.32_fpy49.98.jpg',
opcoes: ['Verdadeira', 'Falsa'],
respostaCerta: 0
},
{
id: 10,
pergunta: 'Na mais recente temporada de From(4° temporada), Oque se descobriu sobre os personagens da Tabitha e Jade?',
imagem: 'https://preview.redd.it/jade-and-tabitha-v0-k5y6k67x3z2e1.jpeg?auto=webp&s=3150ec1db739e588f433e713a4792684da259c15',
opcoes: [
'A)Que eles são irmãos' ,
'B)Que quem traiu jade foi Tabitha' , 
'C)Que Jade e Tabitha estavam mortos' ,
'D)Que eles vivem num ciclo de reencarnação'],
respostaCerta: 3
}
];
export default function AppQuiz() {
const [telaAtual, setTelaAtual] = useState('inicio');
const [perguntaAtual, setPerguntaAtual] = useState(0);
const [pontuacao, setPontuacao] = useState(0);
const [carregando, setCarregando] = useState(false);
const [opcaoselecionada,setOpcaoselecionada] = useState(null);
const [bloqueada,setBloqueada] = useState(false);
const [mostrarResposta, setMostrarResposta] = useState(false);
function iniciarJogo() {
setPerguntaAtual(0);
setPontuacao(0);
setTelaAtual('quiz');
}
function voltarAoInicio() {
setTelaAtual('inicio');
}
function responder(indiceClicado) {
  if (bloqueada) return;
    const pergunta = QUIZ[perguntaAtual];
    const acertou = indiceClicado === pergunta.respostaCerta;
    setBloqueada(true);
    setOpcaoselecionada(indiceClicado);
    setMostrarResposta(true);
   if (acertou) {
      setPontuacao(prev => prev + 1);
    }
    setTimeout(() => {
      setCarregando(true);
    setTimeout(() => {
      setCarregando(false);
      setMostrarResposta(false);
      setOpcaoselecionada(null);
      setBloqueada(false);
      
      if (perguntaAtual + 1 < QUIZ.length) {
        setPerguntaAtual(prev => prev + 1);
      } else {
        setTelaAtual('resultado');
      }
     }, 1000); 

  }, 1000); 
}

// ==========================================
// AS TELAS
// ==========================================
if (telaAtual === 'inicio') {
return (
<View style={styles.telaCentrada}>
{/* 2. EXEMPLO PRÁTICO DE IMAGEM: */}
{/* Repare nas chaves duplas {{ }} usadas para passar o link da internet */}
<Image
source={{ uri: 'https://imgblogchicorei.imgix.net/content/images/2021/10/capa-cinema-em-casa.jpg?auto=compress%2Cformat&q=65&w=1000' }}
style={styles.logoInicial}
/>
<Text style={styles.tituloPrincipal}>Quiz sobre séries</Text>
<Text style={styles.subtituloInicio}>Oque você sabe sobre essas 5 séries:Twin Peaks, True detective, Breaking bad, From e Dark?</Text>
<TouchableOpacity style={styles.botaoIniciar} onPress={iniciarJogo} activeOpacity={0.8}>
<Text style={styles.textoBotaoIniciar}>INICIAR QUIZ</Text>
</TouchableOpacity>
</View>
);
}
if (telaAtual === 'resultado') {
return (
<View style={styles.telaCentrada}>
<Text style={styles.iconeGrande}> </Text>
<Text style={styles.titulo}>Fim de Jogo!</Text>
<Text style={styles.subtitulo}>Você acertou {pontuacao} de {QUIZ.length} perguntas.</Text>
<TouchableOpacity style={styles.botaoAcao} onPress={voltarAoInicio} activeOpacity={0.8}>
<Text style={styles.textoBotaoAcao}>Voltar ao Início</Text>
</TouchableOpacity>
</View>
);
}
if (carregando) {
return (
<View style={styles.telaCentrada}>
<ActivityIndicator size="large" color="#3b82f6" />
<Text style={styles.textoCarregando}>Validando resposta...</Text>
</View>
);
}
const pergunta = QUIZ[perguntaAtual];
return (
<View style={styles.tela}>
<View style={styles.cabecalho}>
<Text style={styles.progresso}>Pergunta {perguntaAtual + 1} de {QUIZ.length}</Text>
<Text style={styles.pontos}>Pontos: {pontuacao}</Text>
</View>
<View style={styles.cartaoPergunta}>
<Image
    source={{ uri: pergunta.imagem }}
    style={styles.imagemPergunta}
/>
<Text style={styles.textoPergunta}>{pergunta.pergunta}</Text>
</View>
<View style={styles.areaOpcoes}>
{pergunta.opcoes.map((opcao, index) => {
const correta = index === pergunta.respostaCerta;
return(

<TouchableOpacity
disabled = {bloqueada}
key={index}
style={[styles.botaoOpcao, mostrarResposta && index === pergunta.respostaCerta && styles.botaoOpcaoMarcadaCorreta, mostrarResposta && opcaoselecionada === index &&  index != pergunta.respostaCerta && styles.botaoOpcaoMarcadaErrado
]}
onPress={() => responder(index)} 
activeOpacity={0.7}
>
<Text style={styles.textoOpcao}>{opcao}</Text>
</TouchableOpacity>
);
})}
</View>
</View>
);
}
// ==========================================
// ESTILOS
// ==========================================
const styles = StyleSheet.create({
tela: { flex: 1, backgroundColor: '#001219', padding: 20, paddingTop: 60 },
telaCentrada: { flex: 1, backgroundColor: 'black', justifyContent: 'center', alignItems: 'center', padding: 20 },
// 3. ESTILO DA IMAGEM
logoInicial: { width: 300, height: 300, marginBottom: 20 },
tituloPrincipal: { fontSize: 36, fontWeight: '900', color: '#8B0000', marginBottom: 10, textAlign: 'center' },
subtituloInicio: { fontSize: 16, color: '#8B0000', marginBottom: 50, textAlign: 'center', paddingHorizontal: 20 },
botaoIniciar: { backgroundColor: '#880808', paddingVertical: 20, paddingHorizontal: 40, borderRadius: 20, width: '100%', maxWidth: 300, shadowColor: '#10b981', shadowOpacity: 0.4, shadowRadius: 15, elevation: 8, alignItems: 'center' },
textoBotaoIniciar: { color: 'white', fontSize: 20, fontWeight: '900', letterSpacing: 1 },
cabecalho: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 30, paddingHorizontal: 10 },
progresso: { fontSize: 16, fontWeight: '700', color: '#64748b' },
pontos: { fontSize: 16, fontWeight: '800', color: '#8B0000' },
cartaoPergunta: { backgroundColor: 'white', padding: 30, borderRadius: 20, marginBottom: 30,shadowColor: '#0f172a', shadowOpacity: 0.05, shadowRadius: 15, elevation: 5, minHeight: 150, justifyContent: 'center',alignItems: 'center' },
textoPergunta: { fontSize: 22, fontWeight: '800', color: '#8B0000', textAlign: 'center', lineHeight: 30 },
areaOpcoes: { flex: 1 },
botaoOpcao: { backgroundColor: 'white', padding: 20, borderRadius: 15, marginBottom: 15, borderWidth: 2, borderColor: '#e2e8f0' },
botaoOpcaoMarcadaCorreta: {borderColor: 'green', borderWidth : 3, backgroundColor:'green'}, 
botaoOpcaoMarcadaErrado: {borderColor: 'Red', borderWidth: 3, backgroundColor: 'red'},
textoOpcao: { fontSize: 18, color: '#334155', fontWeight: '600', textAlign: 'center' },
iconeGrande: { fontSize: 80, marginBottom: 20 },
titulo: { fontSize: 32, fontWeight: '900', color: '#8B0000', marginBottom: 10 },
subtitulo: { fontSize: 18, color: '#64748b', marginBottom: 40 },
botaoAcao: { backgroundColor: '#8B0000', paddingVertical: 18, paddingHorizontal: 40, borderRadius: 16, width: '100%', maxWidth: 300, alignItems: 'center' },
textoBotaoAcao: { color: 'white', fontSize: 18, fontWeight: '800' },
textoCarregando: { marginTop: 20, fontSize: 18, fontWeight: '600', color: '#3b82f6' },
imagemPergunta :{width: 250,height: 150,borderRadius: 10,marginBottom: 15 }
});
